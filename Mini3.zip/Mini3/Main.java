public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("Kelvin", "Osaro", 5, 9, 12345, 20.0);

        System.out.println(emp);

        emp.getRaise();
        System.out.println("After raise: " + emp.getHourlyPay());

        double weeklyPay = emp.payDay(40);
        System.out.println("Weekly pay for 40 hours: $" + weeklyPay);
    }
}


