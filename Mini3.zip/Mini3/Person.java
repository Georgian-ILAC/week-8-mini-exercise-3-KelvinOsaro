public class Person {
    private String firstName = "Klevin";
    private String lastName  = "Osaro";
    private int heightFeet;
    private int heightInches;

    public Person(String firstName, String lastName, int heightFeet, int heightInches) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.heightFeet = heightFeet;
        this.heightInches = heightInches;
    }

    // Getters and Setters for Person class
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getHeightFeet() {
        return heightFeet;
    }

    public void setHeightFeet(int heightFeet) {
        this.heightFeet = heightFeet;
    }

    public int getHeightInches() {
        return heightInches;
    }

    public void setHeightInches(int heightInches) {
        this.heightInches = heightInches;
    }

    @Override
    public String toString() {
        return String.format("Name: %s %s\nThey are %d' %d\"\n",
                firstName, lastName, heightFeet, heightInches);
    }
}
