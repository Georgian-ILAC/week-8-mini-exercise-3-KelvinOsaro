public class Employee extends Person {
    private int id;
    private double hourlyPay;

    public Employee(String firstName, String lastName, int heightFeet, int heightInches, int id, double hourlyPay) {
        super(firstName, lastName, heightFeet, heightInches);
        this.id = id;
        this.hourlyPay = hourlyPay;
    }

    // Getters and Setters for Employee class
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getHourlyPay() {
        return hourlyPay;
    }

    public void setHourlyPay(double hourlyPay) {
        this.hourlyPay = hourlyPay;
    }
    public double getRaise() {
        this.hourlyPay *= 1.5;
        return this.hourlyPay;
    }

    public double payDay(int hoursWorked) {
        if (hoursWorked > 40) {
            int overtimeHours = hoursWorked - 40;
            return (40 * hourlyPay) + (overtimeHours * hourlyPay * 2.0);
        } else {
            return hoursWorked * hourlyPay;
        }
    }
    
    
}
